<?php
/**
 * User: Jeron, Timomthy, Milan
 * Date: 12-4-2021
 * File: index.php
 */
?>
<!DOCTYPE html>
<html lang="nl">
    <head>
        <title>
            <?php
                echo 'Praktijk Home pagina';
            ?>
        </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/Stylesheet.css" rel="stylesheet">
    </head>
            <body>
            <header>
    <!--            De navigatie wordt via een andere bestand gelinkt-->
                 <?php
                     include "Includes/Navigation.php";
                 ?>
            </header>
            <main>
            </main>
        </body>
</html>
