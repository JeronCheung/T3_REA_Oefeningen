<?php
/**
 * User: Jeron, Timomthy, Milan
 * Date: 12-4-2021
 * File: nav.php
 */
?>
<!--op deze pagina is het navigatie menu weergeven. ook als het kleiner wordt. is de grootte aangepast-->
<link  rel="stylesheet" href="../../Praktijk//css/nav.css">
<nav>
    <label id="opmaak2" for='toggle'>&equiv;</label>
    <input type="checkbox" id="toggle">
    <ul id="menu_list">
<!--        menu opties -->
        <li><img id="kw1c_Logo" src="../../Praktijk/foto/kon.PNG" alt="Logo van KW1C"></li>
        <li><a id="left_text" href="../../Praktijk/index.php">Home</a></li>
        <li><a href="#">Opleiding</a></li>
        <li><a href="#">StudieKeuze</a></li>
        <li><a href="#">Volwassenen</a></li>
        <li><a href="#">Studentinfo</a></li>
        <li><a href="../../Praktijk/formulier/formulier.php">Formulier</a></li>
        <li> <img id="flag_England" src="../../Praktijk/foto/eng.PNG" alt="Vlag van Engeland"></li>
    </ul>
</nav>
