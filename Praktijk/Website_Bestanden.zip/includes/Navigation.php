<nav>
    <ul>
        <li><img id="kw1c_Logo" src="foto/kon.PNG" alt="Logo van KW1C"></li>
        <li><a id="left_text" href="#">Opleiding</a></li>
        <li><a href="#">StudieKeuze</a></li>
        <li><a href="#">Volwassenen</a></li>
        <li><a href="#">Studentinfo</a></li>
        <li><a href="formulier/formulier.php">Formulier</a></li>
        <li><img id="flag_England" src="foto/eng.PNG" alt="Vlag van Engeland"></li>
    </ul>
</nav>
s